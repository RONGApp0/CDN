INSERT INTO `__PREFIX__theme` VALUES (null,'andhost', 'index', '0');
INSERT INTO `__PREFIX__theme` VALUES (null,'andhost', 'user', '0');